#!/bin/bash
vmd 1mh1_out.pdb -e 1mh1.tcl
