#!/bin/bash
pymol 1mh1.pml
